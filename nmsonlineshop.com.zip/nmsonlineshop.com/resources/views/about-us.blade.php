 @include('header')
<div class="container">    
    <div class="row" style="margin: 0;padding:0;">
    
    
      <div class="panel panel-primary">
        <div class="panel-heading text-center">About Us</div>
        <div class="panel-body">
           
            <h1>About Us</h1>
            </div>
      </div>
     

  </div>
</div>
 
   @include('footer')