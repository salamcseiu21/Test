
 @include('layouts.user-layout')
@section('content')
{{ $data['account-info']->email}}
@endsection

