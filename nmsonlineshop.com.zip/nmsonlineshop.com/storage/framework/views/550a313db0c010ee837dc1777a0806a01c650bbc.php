 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">    
  <div class="row" style="margin: 0;padding:0;">
    
    
      <div class="panel panel-primary">
        <div class="panel-heading text-center">About Us</div>
        <div class="panel-body">
            <h1>About Us</h1>
            </div>
      </div>
     

  </div>
</div>
   <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
