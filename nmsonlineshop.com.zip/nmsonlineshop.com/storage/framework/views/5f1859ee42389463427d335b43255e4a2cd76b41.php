 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section style="padding:30px">
    <h2 class="title text-center" style="margin: 0;">Our Marketplaces</h2>
</section>
 <div class="container">    

        
    
         <div class="row">
      <?php $__currentLoopData = $data['all_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-sm-4" style="margin: 0;padding:5px;">


                                <div class="panel-body text-center" style="background-color: white">



                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->category_image); ?>"  style="width:250px;height: 250px;" alt="Image">

                                    <div class="row text-left" style="padding-top: 15px">
                                          <a href="<?php echo e(url('/')); ?>/product-list-by-id/<?php echo e($row->category_row_id); ?>"> <h3 style="padding-left: 15px;margin: 0;color: darkcyan;text-transform: uppercase;font-weight: bold"><?php echo e($row->category_name); ?></h3></a>

                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0px;">
                                                    <li><a href="#">Online Help</a></li>
                                                    <li><a href="#">Contact Us</a></li>
                                                    <li><a href="#">Order Status</a></li>
                                                  
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="single-widget">

                                                <ul class="nav nav-pills nav-stacked" style="padding-left: 0;">
                                                    <li><a href="#">T-Shirt</a></li>
                                                    <li><a href="#">Mens</a></li>
                                                    <li><a href="#">Womens</a></li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                </div>


                            </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  

         </div>
 </div>

  <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>