 <?php echo $__env->make('superadmin.pages.s-a-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Pending Orders</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                 
                    <th>Customer Info</th>
                    <th>Total Price</th>
                   <th>Order Date</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>User ID</th>
                    <th>Total Price</th>
                   <th>Order Date</th>
                </tr>
              </tfoot>
              <tbody>
                  
                  <?php $__currentLoopData = $data['all_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e(json_decode($row->customer_address)->name); ?></br><?php echo e(json_decode($row->customer_address)->phone); ?></br><?php echo e(json_decode($row->customer_address)->email); ?></td>
                  <td><?php echo e($row->product_total_price); ?></td>
                 <td><?php echo e($row->created_at); ?></td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
   <?php echo $__env->make('superadmin.pages.s-a-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>