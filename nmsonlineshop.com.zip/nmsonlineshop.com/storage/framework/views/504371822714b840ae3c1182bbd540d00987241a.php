 

<?php $__env->startSection('display-product-section'); ?>
<div class="row">
    <div class="col-sm-12">
        <div id="slider-carousel1" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="item active" style="padding: 30px;">
                    <div class="col-sm-5">
                        <div class="row">
                          
                            <div class="panel-body text-center" style="background-color: white;height: 490px">
                                  <img src="<?php echo e(asset("/public/images/products/")); ?>/<?php echo e($data1['product_detals_by_Id']->product_image); ?>"  class="img-responsive" alt="Image">
                             <button type="button" class="btn btn-default get">Get it now</button>
                            </div>
                        
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="row">
                            <?php $__currentLoopData = $data['all_products_by_category_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4" style="margin: 0;padding:0 5px">


                                <div class="panel-body text-center" style="background-color: white">

                                    <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                                        <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:110px;height: 170px;" alt="Image">
                                   </a>    <div class="row" style="margin-top:20px;padding: 0">
                                       <div class="col-sm-6" style="padding-left:0"><?php echo e($row->product_name); ?></div>
                                            <div class="col-sm-6"><?php echo e($row->product_price); ?> Tk</div>
                                              
                                                </div>
                                </div>
                                <div style="height: 10px">
                                   
                                 
                                   
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>




                    </div>
                </div>
                <div class="item" style="padding: 30px">
                    <div class="col-sm-5">
                        <div class="row">
                          
                            <div class="panel-body text-center" style="background-color: white;height: 490px">
                                  <img src="<?php echo e(asset("/public/images/products/")); ?>/<?php echo e($data1['product_detals_by_Id']->product_image); ?>"  class="img-responsive" alt="Image">
                        <button type="button" class="btn btn-default get">Get it now</button>
                            </div>
                        
                        </div>
                    </div>
                    <div class="col-sm-7">


                        <div class="row">
                            <?php $__currentLoopData = $data['all_products_by_category_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4" style="margin: 0;padding:0 5px;">


                                <div class="panel-body text-center" style="background-color: white">

                                    <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                                        <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:110px;height: 170px;" alt="Image">
                                    </a>  <div class="row" style="margin-top:20px;padding: 0">
                                        <div class="col-sm-6" style="padding-left: 0"><?php echo e($row->product_name); ?></div>
                                            <div class="col-sm-6"><?php echo e($row->product_price); ?> Tk</div>
                                              
                                                </div>
                                </div>
                                <div style="height: 10px">
                                   
                                 
                                   
                                </div>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>




                    </div>
                </div>

                <div class="item" style="padding: 30px">
                     <div class="col-sm-5">
                        <div class="row">
                          
                            <div class="panel-body text-center" style="background-color: white;height: 490px">
                                  <img src="<?php echo e(asset("/public/images/products/")); ?>/<?php echo e($data1['product_detals_by_Id']->product_image); ?>"  class="img-responsive" alt="Image">
                        <button type="button" class="btn btn-default get">Get it now</button>
                            </div>
                        
                        </div>
                    </div>
                    <div class="col-sm-7">


                        <div class="row">
                            <?php $__currentLoopData = $data['all_products_by_category_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4" style="margin: 0;padding:0 5px;">


                                <div class="panel-body text-center" style="background-color: white">

                                    <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title=" <?php echo e($row->product_name); ?>"> 

                                        <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:110px;height: 170px;" alt="Image">
                                    </a>
                                     <div class="row" style="margin-top:20px;padding: 0">
                                              <div class="col-sm-6"><?php echo e($row->product_name); ?></div>
                                            <div class="col-sm-6"><?php echo e($row->product_price); ?> Tk</div>
                                              
                                                </div>
                                </div>
                                <div style="height: 10px"></div>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>




                    </div>
                </div>

            </div>

            <a href="#slider-carousel1" class="left control-carousel hidden-xs" data-slide="prev">
                <i class="fa fa-arrow-circle-o-left" style="font-size:30px"></i>
            </a>
            <a href="#slider-carousel1" class="right control-carousel hidden-xs" data-slide="next">
                <i class="fa fa-arrow-circle-o-right" style="font-size:30px"></i>
            </a>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>