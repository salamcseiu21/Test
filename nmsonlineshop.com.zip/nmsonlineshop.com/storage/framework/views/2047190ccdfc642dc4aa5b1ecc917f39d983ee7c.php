@extend('userprofile.profile')
<?php $__env->startSection('content'); ?>
<?php echo e($data['account-info']->email); ?>

<?php $__env->stopSection(); ?>