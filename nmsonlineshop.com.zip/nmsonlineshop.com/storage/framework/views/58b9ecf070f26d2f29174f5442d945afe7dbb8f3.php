 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="container">
    
      <div class="row">
           
     <div class="col-md-4" style="padding: 0px;margin: 0;">
        
        <div class="panel-body">
           
            <a href="#" title="<?php echo e($data['shop_info']->shop_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data['shop_info']->shop_image); ?>"  style="width:250px;height: 290px;" alt="Image" /></a>
            </div>
     
     </div>
       <div class="col-md-8">
           <section style="text-align: left;">
               <h3 style="margin: 0;padding: 10px">
                <?php echo e($data['shop_info']->shop_name); ?>

                  
            </h3>
                <?php echo e($data['shop_info']->about_shop); ?>

           </section>
      </div> 
        
         </div>
  </div>
 <section style="padding:0px">
    <h3 class="text-center" style="color: green;text-transform: uppercase;font-weight: bold">Our Products</h3>
    <h5 class="text-center" style="text-transform: uppercase;font-weight: bold">This is the houseful of Our Products</h5>
</section>


<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                  <div class="row">
                                    <?php $__currentLoopData = $data['product_by_marchant']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                   
                                                                                                       <div class="product-image-wrapper" style="border-style:solid;border-width: 1px;border-color: pink;background-color: white">
										<div class="single-products">
											<div class="productinfo text-center">
												 <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 
           
            <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:170px;height: 200px;" alt="Image">
                </a>
                                                                                            <h2 style="margin:0;padding: 7px"><?php echo e($row->product_price); ?> Tk</h2>
												<p style="margin:0;padding-bottom: 7px"><?php echo e($row->product_name); ?></p>
												
											</div>
											
										</div>
									</div>
                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

            </div>
        </div>
    </div>
</section>
 <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>