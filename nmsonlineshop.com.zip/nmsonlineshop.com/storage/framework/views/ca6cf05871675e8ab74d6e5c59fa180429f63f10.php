<br>

<footer class="container-fluid text-center">
   
  <form class="form-inline">Get deals:
    <input type="email" class="form-control" size="50" placeholder="Email Address">
    <button type="button" class="btn btn-danger">Sign Up</button>
  </form>
  <br>
   <i>All right reserved by <a href="http://www.salamcse.com" target="_blank">www.salamcse.com</a></p>  
</footer>
</body>
</html>
