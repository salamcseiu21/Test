<?php $__env->startSection('marchantcontent'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.marchant-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>