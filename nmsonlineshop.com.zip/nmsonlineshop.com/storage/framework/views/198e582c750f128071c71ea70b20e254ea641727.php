@extend('profile.admin-profile')
 
  <?php $__env->startSection('maincontent'); ?>
  <h3 class="text-center"><u>User Messages</u></h3> 
  <div class="row">
    
  <?php $__currentLoopData = $data['messages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <!-- Post -->
    <div class="col-sm-6">
                <div class="post clearfix">
                  <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="<?php echo e(asset("/public/images/admin")); ?>/<?php echo e($row->image); ?>" alt="User Image">
                        <span class="username">
                          <a href="#"><?php echo e($row->name); ?></a>
                          <a href="#" class="pull-right btn-box-tool"><i class="fa fa-times"></i></a>
                        </span>
                    <span class="description"><?php echo e($row->message_date); ?></span>
                  </div>
                  <!-- /.user-block -->
                  <p>
                    <?php echo e($row->message); ?>

                  </p>

                  <form action="<?php echo e(url('/')); ?>/replay-message" method="post" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                      <div class="col-sm-12">
                          <input type="hidden" name="user_id" value="<?php echo e($row->user_id); ?>">
                        <input type="hidden" name="message_id" value="<?php echo e($row->id); ?>">
                        <textarea class="form-control" name="replymessage" rows="4" placeholder="Write a reply" required></textarea>
                      <br>
                         <button type="submit" class="btn btn-info pull-right  btn-sm">Reply</button>
                      </div>
                     
                    </div>
                  </form>
                </div>
                </div>
                <!-- /.post -->
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </div>
  <?php $__env->stopSection(); ?>