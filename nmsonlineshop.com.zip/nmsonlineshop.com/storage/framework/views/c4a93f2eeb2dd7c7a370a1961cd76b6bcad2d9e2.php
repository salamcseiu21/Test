<?php $__env->startSection('product-section'); ?>

<div class="row" style="padding: 5px">

    <div class="col-md-5" style="padding-left:10px;padding-top: 30px">
        <div class="panel-body" style="padding:10px;background-color: white;">
            <a href="#" title="<?php echo e($data["product_detals_by_Id"]->product_name); ?>"> <img  data-toggle="modal" data-target="#myModal" src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($data["product_detals_by_Id"]->product_image); ?>"  style="width:250px;height: 290px;" alt="Image" /></a>
        </div>
        <br>
        <div class="panel-body" style="padding:10px;background-color: white;">
            <div class="row">
                <div class="col-sm-5">
                     <label>ABOUT MERCHANT</label><br>
                  
            <a href="#" title="<?php echo e($data1["artisan"]->merchant_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data1["artisan"]->merchant_image); ?>"  style="width:100px;height: 110px;" class="img-circle" alt="Image" /></a>
                </div>
                <div class="col-md-7" style="padding-top: 30px;padding-left: 0">
                    <label><?php echo e($data1["artisan"]->merchant_name); ?></label><br>
                     <?php echo e($data1["artisan"]->about_merchant); ?>

                </div>
            </div>
             
        </div>
    </div>
    <div class="col-md-7" style="padding-top:30px;padding-right: 24px">
        <table class="table table-bordered" style="background-color: white">
            <tr>
                <td>
                    <p style="font-size: 15px;padding:0;"> <label> <?php echo e($data["product_detals_by_Id"]->product_name); ?></label><br>
                        NMSCODE : <?php echo e($data["product_detals_by_Id"]->product_row_id); ?> <br>
                        PRICE : <?php echo e($data["product_detals_by_Id"]->product_price); ?> Tk
                    </p>        
                    <form action="<?php echo e(url('/')); ?>/addToCart" method="post">
                        <?php echo e(csrf_field()); ?>

                        <label>Quantity</label>
                        <input type="number" name="quantity" value="1" class="form-control" style="width: 160px;"/>
                        <input type="hidden" name="product_row_id" value="<?php echo e($data["product_detals_by_Id"]->product_row_id); ?>"/><br>
                        <input type="submit" name="submit" value="Add to Cart" class="btn" style="background-color: darkcyan;color: white;padding-top: 5px" />
                    </form>
                </td>
            </tr>
        </table>
        <table class="table table-bordered" style="background-color: white">
            <tr>
                <td>
                    <label>
                        PRODUCT'S OVERVIEW
                    </label>
                    <br>
                    <?php echo e($data["product_detals_by_Id"]->product_short_description); ?><br/>

                </td>
            </tr>
        </table>
        <div class="row"  style="background-color: white;margin: 0;padding: 0">
            <div class="col-sm-3" style="padding: 20px"> 
                <label>ABOUT SHOP</label>
                <br>
                  <a href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($data1["artisan"]->merchant_id); ?>" title="<?php echo e($data1["artisan"]->shop_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data1["artisan"]->shop_image); ?>"  style="width:100px;height: 110px;" alt="Image" /></a>
                
            </div>
            <div class="col-sm-9" style="margin-top: 50px;padding-left: 0;padding-bottom: 20px">
                <label><?php echo e($data1["artisan"]->shop_name); ?></label> <br>
                <i class="fa fa-location-arrow"></i> <?php echo e($data1["artisan"]->shop_location); ?><br><br>
                  <?php echo e($data1["artisan"]->about_shop); ?>

            </div>
        </div>
        
    </div> 


</div>
<!-- Trigger the modal with a button -->
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo e($data['product_detals_by_Id']->product_name); ?></h4>
            </div>
            <div class="modal-body">
                <img  data-toggle="modal" data-target="#myModal" src="<?php echo e(asset('/public/images/products')); ?>/<?php echo e($data['product_detals_by_Id']->product_image); ?>" class="img-responsive" style="width:100%" alt="Image">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('single-product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>