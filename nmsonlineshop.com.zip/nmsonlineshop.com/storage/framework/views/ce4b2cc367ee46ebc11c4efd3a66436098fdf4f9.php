<?php $__env->startSection('maincontent'); ?>
<div class="container">		
		<div class="panel panel-primary">
		  <div class="panel-heading">
		    <h3 class="panel-title" style="padding:12px 0px;font-size:25px;"><strong>Import export csv or excel file into database example</strong></h3>
		  </div>
		  <div class="panel-body">

		  		<?php if($message = Session::get('success')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo e(Session::get('success')); ?>

					</div>
				<?php endif; ?>

				<?php if($message = Session::get('error')): ?>
					<div class="alert alert-danger" role="alert">
						<?php echo e(Session::get('error')); ?>

					</div>
				<?php endif; ?>

				<h3>Import File Form:</h3>
				<form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 20px;" action="<?php echo e(url('/importExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">

					<input type="file" name="import_file" />
					<?php echo e(csrf_field()); ?>

					<br/>

					<button class="btn btn-primary">Import CSV or Excel File</button>

				</form>
				<br/>

		    	
		    	<h3>Import File From Database:</h3>
		    	<div style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 20px;"> 		
			    	<a href="<?php echo e(url('downloadExcel/xls')); ?>"><button class="btn btn-success btn-lg">Download Excel xls</button></a>
					<a href="<?php echo e(url('downloadExcel/xlsx')); ?>"><button class="btn btn-success btn-lg">Download Excel xlsx</button></a>
					<a href="<?php echo e(url('downloadExcel/csv')); ?>"><button class="btn btn-success btn-lg">Download CSV</button></a>
		    	</div>

		  </div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>