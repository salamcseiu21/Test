 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <div class="container">
    
      <div class="row">
           
     <div class="col-md-5" style="padding: 0px;margin: 0;">
        
        <div class="panel-body">
           
            <a href="#" title="<?php echo e($data["artisan"]->merchant_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data["artisan"]->merchant_image); ?>"  style="width:250px;height: 290px;" alt="Image" /></a>
            </div>
     <h3 style="margin: 0;padding: 10px">
                <?php echo e($data["artisan"]->merchant_name); ?>

                  
            </h3>
     </div>
       <div class="col-md-7">
           <section>
                <?php echo e($data["artisan"]->about_merchant); ?>

           </section>
      </div> 
        
         </div>
  </div>
 <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>