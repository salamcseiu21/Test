   <script src="<?php echo e(asset('/public/Admin/vendor/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo e(asset('/public/Admin/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo e(asset('/public/Admin/vendor/metisMenu/metisMenu.min.js')); ?>"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo e(asset('/public/Admin/vendor/raphael/raphael.min.js')); ?>"></script>
   <script src="<?php echo e(asset('/public/Admin/vendor/morrisjs/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/Admin/dist/js/sb-admin-2.js')); ?>"></script>

   

</body>

</html>
